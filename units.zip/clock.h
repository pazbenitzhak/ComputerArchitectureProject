#ifndef CLOCK_H
#define CLOCK_H

static unsigned long cycle;

void updateClock();
unsigned long getClock();
void initClock();

#endif
