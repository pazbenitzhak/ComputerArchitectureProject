
#include "memory.h"
//#include "units.h"

int main(int argc, char** argv) {
    printf("hi\n");
    initMemory("memin.txt","memout.txt");
}